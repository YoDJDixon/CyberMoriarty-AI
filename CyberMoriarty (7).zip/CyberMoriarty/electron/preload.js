const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  
  showSaveDialog: () => ipcRenderer.invoke('show-save-dialog'),
  showOpenDialog: () => ipcRenderer.invoke('show-open-dialog'),
  
  // Listen for menu actions
  onOpenPreferences: (callback) => ipcRenderer.on('open-preferences', callback),
  onShowSafeModeStatus: (callback) => ipcRenderer.on('show-safe-mode-status', callback),
  onNavigateToAudit: (callback) => ipcRenderer.on('navigate-to-audit', callback),
  onNavigateToApprovals: (callback) => ipcRenderer.on('navigate-to-approvals', callback),
  
  // Remove listeners
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel),
  
  // Platform info
  platform: process.platform,
  isElectron: true
});

// Expose a limited API for security operations
contextBridge.exposeInMainWorld('securityAPI', {
  exportAuditLogs: async (data) => {
    const result = await ipcRenderer.invoke('show-save-dialog');
    if (!result.canceled) {
      return { filePath: result.filePath };
    }
    return { canceled: true };
  },
  
  importTargets: async () => {
    const result = await ipcRenderer.invoke('show-open-dialog');
    if (!result.canceled) {
      return { filePath: result.filePaths[0] };
    }
    return { canceled: true };
  }
});