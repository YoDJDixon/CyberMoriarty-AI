import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("operator"),
  fullName: text("full_name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const targets = pgTable("targets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  hostname: text("hostname").notNull(),
  ipAddress: text("ip_address").notNull(),
  priority: text("priority").notNull().default("medium"),
  vulnerabilityCount: integer("vulnerability_count").default(0),
  lastScanTime: timestamp("last_scan_time"),
  status: text("status").default("active"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vulnerabilities = pgTable("vulnerabilities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetId: varchar("target_id").references(() => targets.id),
  cveId: text("cve_id"),
  severity: text("severity").notNull(),
  description: text("description"),
  exploitAvailable: boolean("exploit_available").default(false),
  riskScore: integer("risk_score"),
  discoveredAt: timestamp("discovered_at").defaultNow(),
});

export const approvals = pgTable("approvals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetId: varchar("target_id").references(() => targets.id),
  requestedBy: varchar("requested_by").references(() => users.id),
  approvedBy: varchar("approved_by").references(() => users.id),
  status: text("status").default("pending"),
  expiresAt: timestamp("expires_at"),
  requestDetails: jsonb("request_details"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  action: text("action").notNull(),
  targetId: varchar("target_id").references(() => targets.id),
  details: jsonb("details"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const aiModels = pgTable("ai_models", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  version: text("version").notNull(),
  accuracy: integer("accuracy"),
  predictions: integer("predictions").default(0),
  falsePositives: integer("false_positives").default(0),
  isActive: boolean("is_active").default(false),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  fullName: true,
});

export const insertTargetSchema = createInsertSchema(targets).pick({
  hostname: true,
  ipAddress: true,
  priority: true,
  metadata: true,
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilities).pick({
  targetId: true,
  cveId: true,
  severity: true,
  description: true,
  exploitAvailable: true,
  riskScore: true,
});

export const insertApprovalSchema = createInsertSchema(approvals).pick({
  targetId: true,
  requestedBy: true,
  expiresAt: true,
  requestDetails: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).pick({
  userId: true,
  action: true,
  targetId: true,
  details: true,
  ipAddress: true,
  userAgent: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTarget = z.infer<typeof insertTargetSchema>;
export type Target = typeof targets.$inferSelect;

export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;
export type Vulnerability = typeof vulnerabilities.$inferSelect;

export type InsertApproval = z.infer<typeof insertApprovalSchema>;
export type Approval = typeof approvals.$inferSelect;

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;

export type AIModel = typeof aiModels.$inferSelect;
