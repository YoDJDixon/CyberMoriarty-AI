#!/usr/bin/env node

/**
 * CyberMoriarty Desktop Application Launcher
 * Automatically handles server startup and Electron app launch
 */

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';
import { setTimeout } from 'timers/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isDev = process.env.NODE_ENV !== 'production';
const serverPort = process.env.PORT || 5000;

let serverProcess = null;
let electronProcess = null;

console.log('🚀 CyberMoriarty AI Exploitation Desktop Engine');
console.log('   Starting desktop application...\n');

// Kill processes on exit
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
process.on('exit', cleanup);

async function startServer() {
  return new Promise((resolve, reject) => {
    console.log('⚡ Starting backend server...');
    
    serverProcess = spawn('npm', ['run', 'dev'], {
      stdio: 'pipe',
      env: { ...process.env, NODE_ENV: 'development' }
    });

    let serverStarted = false;

    serverProcess.stdout.on('data', (data) => {
      const output = data.toString();
      console.log(`[SERVER] ${output.trim()}`);
      
      if (output.includes('serving on port') || output.includes(`listening on ${serverPort}`)) {
        if (!serverStarted) {
          serverStarted = true;
          console.log('✅ Backend server ready\n');
          resolve();
        }
      }
    });

    serverProcess.stderr.on('data', (data) => {
      const output = data.toString();
      if (!output.includes('EADDRINUSE')) {
        console.error(`[SERVER ERROR] ${output.trim()}`);
      }
    });

    serverProcess.on('error', (error) => {
      if (!serverStarted) {
        console.log('⚠️  Server already running or starting via existing process');
        resolve(); // Continue anyway, server might already be running
      }
    });

    // Timeout fallback
    setTimeout(5000).then(() => {
      if (!serverStarted) {
        console.log('⚠️  Server startup timeout - continuing with existing server');
        resolve();
      }
    });
  });
}

async function startElectron() {
  console.log('🖥️  Launching desktop application...');
  
  electronProcess = spawn('electron', ['desktop.js'], {
    stdio: 'inherit',
    env: { ...process.env, NODE_ENV: 'development' }
  });

  electronProcess.on('error', (error) => {
    console.error('❌ Failed to start desktop app:', error.message);
    console.log('💡 Make sure Electron is installed: npm install electron');
    cleanup();
  });

  electronProcess.on('close', (code) => {
    console.log(`\n🔌 Desktop application closed (code: ${code})`);
    cleanup();
  });
}

function cleanup() {
  console.log('\n🧹 Cleaning up processes...');
  
  if (electronProcess) {
    electronProcess.kill('SIGTERM');
    electronProcess = null;
  }
  
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
    serverProcess = null;
  }
  
  setTimeout(1000).then(() => {
    process.exit(0);
  });
}

async function main() {
  try {
    await startServer();
    await startElectron();
  } catch (error) {
    console.error('❌ Failed to start application:', error);
    cleanup();
  }
}

// Launch the application
main();