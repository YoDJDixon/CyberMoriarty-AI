#!/bin/bash

echo "Starting CyberMoriarty Desktop Application..."
echo ""

# Start the backend server in the background
echo "Starting backend server..."
npm run dev &
SERVER_PID=$!

# Wait for server to be ready
echo "Waiting for server to start..."
sleep 5

# Start Electron desktop app
echo "Starting desktop application..."
electron desktop.js

# Cleanup
kill $SERVER_PID 2>/dev/null