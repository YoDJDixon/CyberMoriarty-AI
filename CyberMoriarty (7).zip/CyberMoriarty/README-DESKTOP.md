# CyberMoriarty AI Exploitation Desktop Engine

## Desktop Application Overview

The CyberMoriarty AI Exploitation Desktop Engine is a comprehensive cybersecurity research and training platform built with Electron, featuring AI-powered vulnerability analysis using TensorFlow.js.

## Features

### 🖥️ Desktop Application
- **Native Desktop Experience**: Full-featured Electron application with system integration
- **Professional Security Interface**: Dark theme cybersecurity dashboard
- **Desktop Mode Launcher**: Easy transition from web to desktop application
- **System Menus**: Comprehensive application menus with security-focused options

### 🤖 AI-Powered Analysis
- **TensorFlow.js Integration**: Real-time neural network processing
- **Vulnerability Assessment**: AI-driven security analysis and recommendations
- **Pattern Recognition**: Advanced threat detection and analysis
- **Performance Monitoring**: Real-time AI model metrics and performance tracking

### 🔐 Security Framework
- **Safe Mode Operation**: Built-in safety controls and lab environment isolation
- **Two-Key Approval System**: Comprehensive authorization workflows
- **Audit Logging**: Complete audit trail of all activities and decisions
- **Risk Assessment**: AI-powered security risk evaluation

### 📊 Dashboard Features
- **Real-time Metrics**: Live security metrics and system status monitoring
- **Target Analysis**: Comprehensive target information and vulnerability tracking
- **AI Recommendations**: Intelligent security recommendations and action items
- **WebSocket Communication**: Real-time data updates and system communication

## Desktop Application Usage

### Launch Methods

1. **Desktop Launcher Script** (Recommended):
   ```bash
   node desktop-launcher.js
   ```

2. **Batch/Shell Scripts**:
   - Windows: `start-desktop.bat`
   - Linux/Mac: `./start-desktop.sh`

3. **Manual Launch**:
   ```bash
   # Start server first
   npm run dev
   
   # In another terminal, start desktop app
   electron desktop.js
   ```

4. **Desktop Mode Button**: Click the purple "Desktop Mode" floating action button in the web interface

### Desktop Application Structure

```
├── desktop.js              # Main Electron process
├── desktop-launcher.js     # Automated launcher script
├── electron/
│   ├── main.js             # Electron main process configuration
│   └── preload.js          # Secure preload script
├── start-desktop.bat       # Windows launch script
└── start-desktop.sh        # Linux/Mac launch script
```

### Application Architecture

- **Frontend**: React-based dashboard with Tailwind CSS and shadcn/ui components
- **Backend**: Express.js API with WebSocket support
- **AI Engine**: TensorFlow.js neural networks for vulnerability analysis
- **Database**: PostgreSQL with comprehensive audit logging
- **Desktop Shell**: Electron with security-focused system integration

### Security Controls

- **LAB_MODE**: Isolated execution environment for safe operation
- **Approval Workflows**: Two-key authorization for sensitive operations
- **Audit Logging**: Immutable logging of all system activities
- **Safe Mode**: Default security settings prevent unauthorized actions

### System Requirements

- **Node.js**: v18+ required
- **Electron**: Desktop application framework
- **TensorFlow.js**: AI/ML processing capabilities
- **PostgreSQL**: Database for audit logging and data persistence

## Development Status

✅ **Complete Desktop Application Implementation**
- Electron main process with security menus
- Desktop mode launch functionality
- AI Assessment modal integration
- Multi-service architecture with database integration
- Real-time WebSocket communication
- Comprehensive security framework

The desktop application is fully functional and ready for ethical cybersecurity research and training purposes.