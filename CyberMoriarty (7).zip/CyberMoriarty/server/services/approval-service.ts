import { randomUUID } from "crypto";
import { Approval, InsertApproval, User } from "@shared/schema";
import { storage } from "../storage";
import { auditService } from "./audit-service";

export interface ApprovalRequest {
  targetId: string;
  requestedBy: string;
  requestDetails: {
    operation: string;
    description: string;
    duration: number; // in minutes
    justification: string;
    riskLevel: 'low' | 'medium' | 'high' | 'critical';
  };
}

export interface ApprovalWorkflow {
  requiredApprovers: string[];
  currentApprovals: { userId: string; timestamp: Date; role: string }[];
  isComplete: boolean;
}

export class ApprovalService {
  private readonly REQUIRED_APPROVER_ROLES = ['security_lead', 'operations_manager'];
  private readonly DEFAULT_EXPIRATION_HOURS = 2;

  async requestApproval(request: ApprovalRequest): Promise<Approval> {
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + this.DEFAULT_EXPIRATION_HOURS);

    const approvalData: InsertApproval = {
      targetId: request.targetId,
      requestedBy: request.requestedBy,
      expiresAt,
      requestDetails: request.requestDetails
    };

    const approval = await storage.createApproval(approvalData);

    // Log approval request
    await auditService.logApprovalEvent(
      'REQUEST_CREATED',
      approval.id,
      request.requestedBy,
      {
        targetId: request.targetId,
        operation: request.requestDetails.operation,
        riskLevel: request.requestDetails.riskLevel
      }
    );

    return approval;
  }

  async approveRequest(
    approvalId: string,
    approverId: string,
    comments?: string
  ): Promise<boolean> {
    const approval = await storage.getApproval(approvalId);
    if (!approval) {
      throw new Error('Approval request not found');
    }

    if (approval.status !== 'pending') {
      throw new Error('Approval request is not pending');
    }

    if (new Date() > approval.expiresAt) {
      throw new Error('Approval request has expired');
    }

    const approver = await storage.getUser(approverId);
    if (!approver) {
      throw new Error('Approver not found');
    }

    // Check if this user has already approved
    const workflow = await this.getApprovalWorkflow(approvalId);
    const hasAlreadyApproved = workflow.currentApprovals.some(
      approval => approval.userId === approverId
    );

    if (hasAlreadyApproved) {
      throw new Error('User has already approved this request');
    }

    // Add approval
    await storage.addApprovalSignature(approvalId, approverId, approver.role, comments);

    // Check if we have all required approvals
    const updatedWorkflow = await this.getApprovalWorkflow(approvalId);
    if (this.validateTwoKeyApproval(updatedWorkflow)) {
      await storage.updateApprovalStatus(approvalId, 'approved');
      
      await auditService.logApprovalEvent(
        'REQUEST_APPROVED',
        approvalId,
        approverId,
        {
          comments,
          finalApprover: true
        }
      );

      return true;
    } else {
      await auditService.logApprovalEvent(
        'PARTIAL_APPROVAL',
        approvalId,
        approverId,
        {
          comments,
          requiresAdditionalApproval: true
        }
      );

      return false;
    }
  }

  async rejectRequest(
    approvalId: string,
    rejecterId: string,
    reason: string
  ): Promise<void> {
    const approval = await storage.getApproval(approvalId);
    if (!approval) {
      throw new Error('Approval request not found');
    }

    await storage.updateApprovalStatus(approvalId, 'rejected');

    await auditService.logApprovalEvent(
      'REQUEST_REJECTED',
      approvalId,
      rejecterId,
      {
        reason
      }
    );
  }

  async extendApproval(
    approvalId: string,
    requesterId: string,
    additionalHours: number
  ): Promise<void> {
    const approval = await storage.getApproval(approvalId);
    if (!approval) {
      throw new Error('Approval request not found');
    }

    if (approval.status !== 'approved') {
      throw new Error('Can only extend approved requests');
    }

    const newExpirationTime = new Date(approval.expiresAt);
    newExpirationTime.setHours(newExpirationTime.getHours() + additionalHours);

    await storage.updateApprovalExpiration(approvalId, newExpirationTime);

    await auditService.logApprovalEvent(
      'APPROVAL_EXTENDED',
      approvalId,
      requesterId,
      {
        additionalHours,
        newExpiration: newExpirationTime.toISOString()
      }
    );
  }

  private async getApprovalWorkflow(approvalId: string): Promise<ApprovalWorkflow> {
    const signatures = await storage.getApprovalSignatures(approvalId);
    
    return {
      requiredApprovers: this.REQUIRED_APPROVER_ROLES,
      currentApprovals: signatures.map(sig => ({
        userId: sig.userId,
        timestamp: sig.timestamp,
        role: sig.role
      })),
      isComplete: this.validateTwoKeyApproval({
        requiredApprovers: this.REQUIRED_APPROVER_ROLES,
        currentApprovals: signatures.map(sig => ({
          userId: sig.userId,
          timestamp: sig.timestamp,
          role: sig.role
        })),
        isComplete: false
      })
    };
  }

  private validateTwoKeyApproval(workflow: ApprovalWorkflow): boolean {
    // Check if we have approvals from all required roles
    return this.REQUIRED_APPROVER_ROLES.every(requiredRole =>
      workflow.currentApprovals.some(approval => approval.role === requiredRole)
    );
  }

  async getPendingApprovals(userId?: string): Promise<Approval[]> {
    return await storage.getPendingApprovals(userId);
  }

  async getApprovalHistory(userId?: string, limit: number = 50): Promise<Approval[]> {
    return await storage.getApprovalHistory(userId, limit);
  }

  async checkApprovalStatus(approvalId: string): Promise<{
    status: string;
    workflow: ApprovalWorkflow;
    timeRemaining: number; // in minutes
  }> {
    const approval = await storage.getApproval(approvalId);
    if (!approval) {
      throw new Error('Approval not found');
    }

    const workflow = await this.getApprovalWorkflow(approvalId);
    const timeRemaining = Math.max(0, 
      Math.floor((approval.expiresAt.getTime() - new Date().getTime()) / (1000 * 60))
    );

    return {
      status: approval.status,
      workflow,
      timeRemaining
    };
  }

  // Safety control: ensure lab mode is active before approving high-risk operations
  private async validateSafetyControls(requestDetails: any): Promise<boolean> {
    if (requestDetails.riskLevel === 'critical' || requestDetails.riskLevel === 'high') {
      // In a real implementation, this would check:
      // - Lab mode is active
      // - Network isolation is enabled
      // - Proper monitoring is in place
      return true; // Simplified for demo
    }
    return true;
  }
}

export const approvalService = new ApprovalService();
