import { randomUUID } from "crypto";
import { AuditLog, InsertAuditLog } from "@shared/schema";
import { storage } from "../storage";

export interface AuditEventDetails {
  sessionId?: string;
  ipAddress?: string;
  userAgent?: string;
  targetId?: string;
  additionalData?: any;
}

export class AuditService {
  private auditQueue: AuditLog[] = [];

  async logEvent(
    userId: string,
    action: string,
    details: AuditEventDetails
  ): Promise<void> {
    const auditEntry: InsertAuditLog = {
      userId,
      action,
      targetId: details.targetId,
      details: {
        sessionId: details.sessionId,
        timestamp: new Date().toISOString(),
        additionalData: details.additionalData
      },
      ipAddress: details.ipAddress,
      userAgent: details.userAgent
    };

    try {
      const savedEntry = await storage.createAuditLog(auditEntry);
      console.log(`Audit event logged: ${action} by user ${userId}`);
      
      // Add to queue for real-time updates
      this.auditQueue.push(savedEntry);
      
      // Keep only last 100 entries in memory
      if (this.auditQueue.length > 100) {
        this.auditQueue = this.auditQueue.slice(-100);
      }
    } catch (error) {
      console.error('Failed to log audit event:', error);
    }
  }

  async logSecurityEvent(
    action: string,
    details: AuditEventDetails,
    userId?: string
  ): Promise<void> {
    await this.logEvent(
      userId || 'system',
      `SECURITY: ${action}`,
      details
    );
  }

  async logApprovalEvent(
    action: string,
    approvalId: string,
    userId: string,
    details: any
  ): Promise<void> {
    await this.logEvent(
      userId,
      `APPROVAL: ${action}`,
      {
        ...details,
        additionalData: { approvalId, ...details.additionalData }
      }
    );
  }

  async logAIEvent(
    action: string,
    modelVersion: string,
    details: any
  ): Promise<void> {
    await this.logEvent(
      'ai-system',
      `AI: ${action}`,
      {
        additionalData: { modelVersion, ...details }
      }
    );
  }

  async getRecentEntries(limit: number = 50): Promise<AuditLog[]> {
    return await storage.getRecentAuditLogs(limit);
  }

  async getEntriesByUser(userId: string, limit: number = 50): Promise<AuditLog[]> {
    return await storage.getAuditLogsByUser(userId, limit);
  }

  async getEntriesByAction(action: string, limit: number = 50): Promise<AuditLog[]> {
    return await storage.getAuditLogsByAction(action, limit);
  }

  async searchEntries(
    query: string,
    startDate?: Date,
    endDate?: Date,
    limit: number = 50
  ): Promise<AuditLog[]> {
    return await storage.searchAuditLogs(query, startDate, endDate, limit);
  }

  // Generate JSONL format for external audit systems
  generateJSONLExport(entries: AuditLog[]): string {
    return entries
      .map(entry => JSON.stringify({
        id: entry.id,
        timestamp: entry.timestamp,
        userId: entry.userId,
        action: entry.action,
        targetId: entry.targetId,
        details: entry.details,
        ipAddress: entry.ipAddress,
        userAgent: entry.userAgent,
        hash: this.generateIntegrityHash(entry)
      }))
      .join('\n');
  }

  private generateIntegrityHash(entry: AuditLog): string {
    // In a real implementation, this would use crypto.createHash
    // to generate a SHA-256 hash for integrity verification
    const data = `${entry.id}${entry.timestamp}${entry.userId}${entry.action}`;
    return `sha256_${Buffer.from(data).toString('base64').substring(0, 16)}`;
  }

  // Validate audit log integrity
  validateIntegrity(entries: AuditLog[]): boolean {
    // In a real implementation, this would verify hash chains
    // and detect any tampering with audit records
    return entries.every(entry => {
      const expectedHash = this.generateIntegrityHash(entry);
      // Compare with stored hash in entry.details.hash
      return true; // Simplified for demo
    });
  }
}

export const auditService = new AuditService();
