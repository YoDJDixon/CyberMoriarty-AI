import { randomUUID } from "crypto";
import { AIModel, InsertVulnerability } from "@shared/schema";

export interface VulnerabilityData {
  severity: number;
  age: number;
  exploitability: number;
  targetValue: number;
  networkExposure: number;
  patchAvailable: number;
  activeExploits: number;
  accessComplexity: number;
  authentication: number;
  confidentialityImpact: number;
}

export interface RiskAssessment {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  exploitRecommendations: string[];
  mitigationSteps: string[];
}

export class AIService {
  private models: Map<string, AIModel> = new Map();

  constructor() {
    // Initialize default AI model
    this.initializeDefaultModel();
  }

  private initializeDefaultModel(): void {
    const defaultModel: AIModel = {
      id: randomUUID(),
      name: "CyberMoriarty ML Engine",
      version: "v2.4.1",
      accuracy: 96,
      predictions: 1247,
      falsePositives: 2,
      isActive: true,
      lastUpdated: new Date()
    };
    
    this.models.set(defaultModel.id, defaultModel);
  }

  async assessVulnerabilityRisk(data: VulnerabilityData): Promise<RiskAssessment> {
    // Simulate ML-based risk assessment
    const riskScore = this.calculateRiskScore(data);
    const riskLevel = this.getRiskLevel(riskScore);
    const confidence = Math.min(0.95, Math.max(0.6, riskScore / 10));

    const exploitRecommendations = this.generateExploitRecommendations(data, riskLevel);
    const mitigationSteps = this.generateMitigationSteps(data, riskLevel);

    // Update model statistics
    this.updateModelStats('predictions');

    return {
      riskLevel,
      confidence,
      exploitRecommendations,
      mitigationSteps
    };
  }

  private calculateRiskScore(data: VulnerabilityData): number {
    // Weighted risk calculation based on multiple factors
    const weights = {
      severity: 0.25,
      exploitability: 0.20,
      networkExposure: 0.15,
      targetValue: 0.15,
      activeExploits: 0.10,
      patchAvailable: -0.05, // Negative weight (reduces risk if patch available)
      age: 0.10,
      accessComplexity: -0.05, // Negative weight
      authentication: -0.05, // Negative weight
      confidentialityImpact: 0.10
    };

    let score = 0;
    score += data.severity * weights.severity;
    score += data.exploitability * weights.exploitability;
    score += data.networkExposure * weights.networkExposure;
    score += data.targetValue * weights.targetValue;
    score += data.activeExploits * weights.activeExploits;
    score += data.patchAvailable * weights.patchAvailable;
    score += data.age * weights.age;
    score += data.accessComplexity * weights.accessComplexity;
    score += data.authentication * weights.authentication;
    score += data.confidentialityImpact * weights.confidentialityImpact;

    return Math.max(0, Math.min(10, score));
  }

  private getRiskLevel(score: number): 'low' | 'medium' | 'high' | 'critical' {
    if (score >= 8.5) return 'critical';
    if (score >= 6.5) return 'high';
    if (score >= 4.0) return 'medium';
    return 'low';
  }

  private generateExploitRecommendations(data: VulnerabilityData, riskLevel: string): string[] {
    const recommendations: string[] = [];

    if (riskLevel === 'critical' || riskLevel === 'high') {
      if (data.networkExposure > 0.7) {
        recommendations.push('Network-based exploitation');
        recommendations.push('Remote code execution attempt');
      }
      if (data.authentication < 0.3) {
        recommendations.push('Authentication bypass');
      }
      if (data.accessComplexity < 0.4) {
        recommendations.push('Direct exploitation');
      }
    }

    if (riskLevel === 'medium') {
      recommendations.push('Privilege escalation attack');
      recommendations.push('Information disclosure');
    }

    if (data.activeExploits > 0.5) {
      recommendations.push('Use existing public exploits');
    }

    return recommendations.length > 0 ? recommendations : ['Manual assessment required'];
  }

  private generateMitigationSteps(data: VulnerabilityData, riskLevel: string): string[] {
    const steps: string[] = [];

    if (data.patchAvailable > 0.5) {
      steps.push('Apply available security patches immediately');
    }

    if (data.networkExposure > 0.6) {
      steps.push('Implement network segmentation');
      steps.push('Configure firewall rules to restrict access');
    }

    if (data.authentication < 0.4) {
      steps.push('Strengthen authentication mechanisms');
      steps.push('Implement multi-factor authentication');
    }

    if (riskLevel === 'critical') {
      steps.push('Isolate affected systems immediately');
      steps.push('Monitor for active exploitation attempts');
    }

    return steps.length > 0 ? steps : ['Standard security hardening'];
  }

  async generateAIRecommendations(): Promise<any[]> {
    const recommendations = [
      {
        id: randomUUID(),
        type: 'critical',
        title: 'Critical Vulnerability Detected',
        description: 'CVE-2024-1234 found on web-prod-01. Immediate attention recommended.',
        confidence: 0.95,
        priority: 'high',
        action: 'Review Details'
      },
      {
        id: randomUUID(),
        type: 'warning',
        title: 'Approval Expiring Soon',
        description: 'Lab-DB-Test approval expires in 45 minutes.',
        confidence: 1.0,
        priority: 'medium',
        action: 'Extend Authorization'
      },
      {
        id: randomUUID(),
        type: 'info',
        title: 'ML Model Update',
        description: 'New vulnerability patterns detected. Model retraining recommended.',
        confidence: 0.85,
        priority: 'low',
        action: 'Update Model'
      }
    ];

    this.updateModelStats('predictions', recommendations.length);
    return recommendations;
  }

  private updateModelStats(metric: 'predictions' | 'falsePositives', increment: number = 1): void {
    for (const [id, model] of this.models) {
      if (model.isActive) {
        if (metric === 'predictions') {
          model.predictions += increment;
        } else if (metric === 'falsePositives') {
          model.falsePositives += increment;
        }
        model.lastUpdated = new Date();
        this.models.set(id, model);
      }
    }
  }

  getActiveModel(): AIModel | undefined {
    for (const model of this.models.values()) {
      if (model.isActive) {
        return model;
      }
    }
    return undefined;
  }

  async trainModel(trainingData: any[]): Promise<boolean> {
    // Simulate model training
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const activeModel = this.getActiveModel();
    if (activeModel) {
      // Simulate accuracy improvement after training
      activeModel.accuracy = Math.min(99, activeModel.accuracy + Math.random() * 2);
      activeModel.lastUpdated = new Date();
      this.models.set(activeModel.id, activeModel);
    }

    return true;
  }

  getModelMetrics(): any {
    const activeModel = this.getActiveModel();
    if (!activeModel) {
      return null;
    }

    return {
      accuracy: activeModel.accuracy,
      predictions: activeModel.predictions,
      falsePositives: (activeModel.falsePositives / activeModel.predictions) * 100,
      version: activeModel.version,
      lastUpdated: activeModel.lastUpdated.toISOString()
    };
  }
}

export const aiService = new AIService();
