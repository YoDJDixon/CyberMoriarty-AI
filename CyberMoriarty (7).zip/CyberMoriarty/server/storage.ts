import { 
  User, 
  InsertUser,
  Target,
  InsertTarget,
  Vulnerability,
  InsertVulnerability,
  Approval,
  InsertApproval,
  AuditLog,
  InsertAuditLog
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Target operations
  getTarget(id: string): Promise<Target | undefined>;
  getAllTargets(): Promise<Target[]>;
  createTarget(target: InsertTarget): Promise<Target>;
  updateTarget(id: string, updates: Partial<Target>): Promise<Target>;
  deleteTarget(id: string): Promise<boolean>;

  // Vulnerability operations
  getVulnerability(id: string): Promise<Vulnerability | undefined>;
  getVulnerabilitiesByTarget(targetId: string): Promise<Vulnerability[]>;
  createVulnerability(vulnerability: InsertVulnerability): Promise<Vulnerability>;
  updateVulnerability(id: string, updates: Partial<Vulnerability>): Promise<Vulnerability>;

  // Approval operations
  getApproval(id: string): Promise<Approval | undefined>;
  createApproval(approval: InsertApproval): Promise<Approval>;
  updateApprovalStatus(id: string, status: string): Promise<void>;
  updateApprovalExpiration(id: string, expiresAt: Date): Promise<void>;
  addApprovalSignature(approvalId: string, userId: string, role: string, comments?: string): Promise<void>;
  getApprovalSignatures(approvalId: string): Promise<any[]>;
  getPendingApprovals(userId?: string): Promise<Approval[]>;
  getApprovalHistory(userId?: string, limit?: number): Promise<Approval[]>;

  // Audit log operations
  createAuditLog(auditLog: InsertAuditLog): Promise<AuditLog>;
  getRecentAuditLogs(limit?: number): Promise<AuditLog[]>;
  getAuditLogsByUser(userId: string, limit?: number): Promise<AuditLog[]>;
  getAuditLogsByAction(action: string, limit?: number): Promise<AuditLog[]>;
  searchAuditLogs(query: string, startDate?: Date, endDate?: Date, limit?: number): Promise<AuditLog[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private targets: Map<string, Target> = new Map();
  private vulnerabilities: Map<string, Vulnerability> = new Map();
  private approvals: Map<string, Approval> = new Map();
  private auditLogs: Map<string, AuditLog> = new Map();
  private approvalSignatures: Map<string, any[]> = new Map();

  constructor() {
    this.initializeTestData();
  }

  private initializeTestData(): void {
    // Create test users
    const adminUser: User = {
      id: "admin-1",
      username: "dr.chen",
      password: "hashed_password",
      role: "security_lead",
      fullName: "Dr. Sarah Chen",
      createdAt: new Date()
    };
    this.users.set(adminUser.id, adminUser);

    const opsUser: User = {
      id: "ops-1",
      username: "marcus.rodriguez",
      password: "hashed_password",
      role: "operations_manager",
      fullName: "Marcus Rodriguez",
      createdAt: new Date()
    };
    this.users.set(opsUser.id, opsUser);

    // Create test targets
    const targets: Target[] = [
      {
        id: "target-1",
        hostname: "web-prod-01.company.com",
        ipAddress: "192.168.1.100",
        priority: "high",
        vulnerabilityCount: 7,
        lastScanTime: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        status: "active",
        metadata: { type: "web", environment: "production" },
        createdAt: new Date()
      },
      {
        id: "target-2",
        hostname: "db-staging-02.company.com",
        ipAddress: "192.168.1.200",
        priority: "low",
        vulnerabilityCount: 2,
        lastScanTime: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
        status: "active",
        metadata: { type: "database", environment: "staging" },
        createdAt: new Date()
      },
      {
        id: "target-3",
        hostname: "firewall-01.company.com",
        ipAddress: "192.168.1.1",
        priority: "critical",
        vulnerabilityCount: 12,
        lastScanTime: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
        status: "active",
        metadata: { type: "firewall", environment: "production" },
        createdAt: new Date()
      }
    ];

    targets.forEach(target => this.targets.set(target.id, target));

    // Create test audit logs
    const auditEntries: AuditLog[] = [
      {
        id: "audit-1",
        userId: adminUser.id,
        action: "Exploit approval granted for web-prod-01",
        targetId: "target-1",
        details: { operation: "vulnerability_assessment" },
        ipAddress: "192.168.1.50",
        userAgent: "CyberMoriarty/2.4.1",
        timestamp: new Date(Date.now() - 2 * 60 * 1000) // 2 minutes ago
      },
      {
        id: "audit-2",
        userId: "ai-system",
        action: "AI model updated vulnerability patterns",
        details: { modelVersion: "v2.4.1", accuracy: 96.8 },
        ipAddress: "127.0.0.1",
        userAgent: "AI-Engine/2.4.1",
        timestamp: new Date(Date.now() - 15 * 60 * 1000) // 15 minutes ago
      },
      {
        id: "audit-3",
        userId: opsUser.id,
        action: "Target scan initiated for firewall-01",
        targetId: "target-3",
        details: { scanType: "full_vulnerability_scan" },
        ipAddress: "192.168.1.51",
        userAgent: "CyberMoriarty/2.4.1",
        timestamp: new Date(Date.now() - 60 * 60 * 1000) // 1 hour ago
      }
    ];

    auditEntries.forEach(entry => this.auditLogs.set(entry.id, entry));
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Target operations
  async getTarget(id: string): Promise<Target | undefined> {
    return this.targets.get(id);
  }

  async getAllTargets(): Promise<Target[]> {
    return Array.from(this.targets.values())
      .sort((a, b) => (b.lastScanTime?.getTime() || 0) - (a.lastScanTime?.getTime() || 0));
  }

  async createTarget(insertTarget: InsertTarget): Promise<Target> {
    const id = randomUUID();
    const target: Target = {
      ...insertTarget,
      id,
      vulnerabilityCount: 0,
      status: "active",
      createdAt: new Date()
    };
    this.targets.set(id, target);
    return target;
  }

  async updateTarget(id: string, updates: Partial<Target>): Promise<Target> {
    const target = this.targets.get(id);
    if (!target) throw new Error('Target not found');
    
    const updatedTarget = { ...target, ...updates };
    this.targets.set(id, updatedTarget);
    return updatedTarget;
  }

  async deleteTarget(id: string): Promise<boolean> {
    return this.targets.delete(id);
  }

  // Vulnerability operations
  async getVulnerability(id: string): Promise<Vulnerability | undefined> {
    return this.vulnerabilities.get(id);
  }

  async getVulnerabilitiesByTarget(targetId: string): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values())
      .filter(vuln => vuln.targetId === targetId);
  }

  async createVulnerability(insertVulnerability: InsertVulnerability): Promise<Vulnerability> {
    const id = randomUUID();
    const vulnerability: Vulnerability = {
      ...insertVulnerability,
      id,
      discoveredAt: new Date()
    };
    this.vulnerabilities.set(id, vulnerability);
    return vulnerability;
  }

  async updateVulnerability(id: string, updates: Partial<Vulnerability>): Promise<Vulnerability> {
    const vulnerability = this.vulnerabilities.get(id);
    if (!vulnerability) throw new Error('Vulnerability not found');
    
    const updated = { ...vulnerability, ...updates };
    this.vulnerabilities.set(id, updated);
    return updated;
  }

  // Approval operations
  async getApproval(id: string): Promise<Approval | undefined> {
    return this.approvals.get(id);
  }

  async createApproval(insertApproval: InsertApproval): Promise<Approval> {
    const id = randomUUID();
    const approval: Approval = {
      ...insertApproval,
      id,
      status: "pending",
      createdAt: new Date()
    };
    this.approvals.set(id, approval);
    return approval;
  }

  async updateApprovalStatus(id: string, status: string): Promise<void> {
    const approval = this.approvals.get(id);
    if (!approval) throw new Error('Approval not found');
    
    approval.status = status;
    this.approvals.set(id, approval);
  }

  async updateApprovalExpiration(id: string, expiresAt: Date): Promise<void> {
    const approval = this.approvals.get(id);
    if (!approval) throw new Error('Approval not found');
    
    approval.expiresAt = expiresAt;
    this.approvals.set(id, approval);
  }

  async addApprovalSignature(approvalId: string, userId: string, role: string, comments?: string): Promise<void> {
    const signatures = this.approvalSignatures.get(approvalId) || [];
    signatures.push({
      userId,
      role,
      comments,
      timestamp: new Date()
    });
    this.approvalSignatures.set(approvalId, signatures);
  }

  async getApprovalSignatures(approvalId: string): Promise<any[]> {
    return this.approvalSignatures.get(approvalId) || [];
  }

  async getPendingApprovals(userId?: string): Promise<Approval[]> {
    const pending = Array.from(this.approvals.values())
      .filter(approval => approval.status === 'pending' && approval.expiresAt > new Date());
    
    if (userId) {
      return pending.filter(approval => approval.requestedBy === userId);
    }
    
    return pending;
  }

  async getApprovalHistory(userId?: string, limit: number = 50): Promise<Approval[]> {
    let approvals = Array.from(this.approvals.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    if (userId) {
      approvals = approvals.filter(approval => 
        approval.requestedBy === userId || approval.approvedBy === userId
      );
    }
    
    return approvals.slice(0, limit);
  }

  // Audit log operations
  async createAuditLog(insertAuditLog: InsertAuditLog): Promise<AuditLog> {
    const id = randomUUID();
    const auditLog: AuditLog = {
      ...insertAuditLog,
      id,
      timestamp: new Date()
    };
    this.auditLogs.set(id, auditLog);
    return auditLog;
  }

  async getRecentAuditLogs(limit: number = 50): Promise<AuditLog[]> {
    return Array.from(this.auditLogs.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async getAuditLogsByUser(userId: string, limit: number = 50): Promise<AuditLog[]> {
    return Array.from(this.auditLogs.values())
      .filter(log => log.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async getAuditLogsByAction(action: string, limit: number = 50): Promise<AuditLog[]> {
    return Array.from(this.auditLogs.values())
      .filter(log => log.action.toLowerCase().includes(action.toLowerCase()))
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async searchAuditLogs(
    query: string,
    startDate?: Date,
    endDate?: Date,
    limit: number = 50
  ): Promise<AuditLog[]> {
    let logs = Array.from(this.auditLogs.values());
    
    // Filter by query
    if (query) {
      logs = logs.filter(log => 
        log.action.toLowerCase().includes(query.toLowerCase()) ||
        log.userId.toLowerCase().includes(query.toLowerCase())
      );
    }
    
    // Filter by date range
    if (startDate) {
      logs = logs.filter(log => log.timestamp >= startDate);
    }
    if (endDate) {
      logs = logs.filter(log => log.timestamp <= endDate);
    }
    
    return logs
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
