import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { aiService } from "./services/ai-service";
import { auditService } from "./services/audit-service";
import { approvalService } from "./services/approval-service";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected to WebSocket');
    
    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message);
        console.log('Received WebSocket message:', data);
        
        // Handle different message types
        switch (data.type) {
          case 'subscribe':
            // Handle subscription to real-time updates
            break;
          case 'ping':
            ws.send(JSON.stringify({ type: 'pong' }));
            break;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });

    // Send initial connection confirmation
    ws.send(JSON.stringify({ type: 'connected', payload: { status: 'ready' } }));
  });

  // Broadcast to all connected clients
  function broadcast(type: string, payload: any) {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ type, payload }));
      }
    });
  }

  // Dashboard metrics endpoint
  app.get('/api/dashboard/metrics', async (req, res) => {
    try {
      const targets = await storage.getAllTargets();
      const pendingApprovals = await storage.getPendingApprovals();
      const recommendations = await aiService.generateAIRecommendations();

      const metrics = {
        activeTargets: targets.filter(t => t.status === 'active').length,
        aiRecommendations: recommendations.length,
        pendingApprovals: pendingApprovals.length,
        successRate: 94.2 // This would be calculated from historical data
      };

      res.json(metrics);
    } catch (error) {
      console.error('Error fetching dashboard metrics:', error);
      res.status(500).json({ error: 'Failed to fetch dashboard metrics' });
    }
  });

  // Targets endpoint
  app.get('/api/targets', async (req, res) => {
    try {
      const targets = await storage.getAllTargets();
      
      const targetInfo = targets.map(target => ({
        id: target.id,
        hostname: target.hostname,
        ipAddress: target.ipAddress,
        priority: target.priority,
        vulnerabilityCount: target.vulnerabilityCount,
        lastScan: target.lastScanTime?.toISOString() || new Date().toISOString()
      }));

      res.json(targetInfo);
    } catch (error) {
      console.error('Error fetching targets:', error);
      res.status(500).json({ error: 'Failed to fetch targets' });
    }
  });

  // AI recommendations endpoint
  app.get('/api/ai/recommendations', async (req, res) => {
    try {
      const recommendations = await aiService.generateAIRecommendations();
      res.json(recommendations);
    } catch (error) {
      console.error('Error fetching AI recommendations:', error);
      res.status(500).json({ error: 'Failed to fetch AI recommendations' });
    }
  });

  // AI vulnerability assessment endpoint
  app.post('/api/ai/assess', async (req, res) => {
    try {
      const vulnerabilityData = req.body;
      const assessment = await aiService.assessVulnerabilityRisk(vulnerabilityData);
      
      // Log AI assessment
      await auditService.logAIEvent(
        'VULNERABILITY_ASSESSED',
        'v2.4.1',
        { riskLevel: assessment.riskLevel, confidence: assessment.confidence }
      );

      res.json(assessment);
    } catch (error) {
      console.error('Error assessing vulnerability:', error);
      res.status(500).json({ error: 'Failed to assess vulnerability' });
    }
  });

  // AI model metrics endpoint
  app.get('/api/ai/metrics', async (req, res) => {
    try {
      const metrics = aiService.getModelMetrics();
      res.json(metrics);
    } catch (error) {
      console.error('Error fetching AI metrics:', error);
      res.status(500).json({ error: 'Failed to fetch AI metrics' });
    }
  });

  // Recent audit logs endpoint
  app.get('/api/audit/recent', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const auditLogs = await storage.getRecentAuditLogs(limit);

      const formattedLogs = auditLogs.map(log => ({
        id: log.id,
        action: log.action,
        user: log.userId === 'ai-system' ? 'System' : 
              log.userId === 'admin-1' ? 'Dr. Sarah Chen' :
              log.userId === 'ops-1' ? 'Marcus Rodriguez' : 
              log.userId || 'Unknown',
        timestamp: log.timestamp?.toISOString() || new Date().toISOString(),
        type: log.action.includes('SECURITY') ? 'warning' :
              log.action.includes('AI') ? 'info' :
              log.action.includes('ERROR') ? 'error' : 'success'
      }));

      res.json(formattedLogs);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      res.status(500).json({ error: 'Failed to fetch audit logs' });
    }
  });

  // Approval request endpoint
  app.post('/api/approvals/request', async (req, res) => {
    try {
      const approvalRequest = req.body;
      const approval = await approvalService.requestApproval(approvalRequest);
      
      // Broadcast new approval request
      broadcast('new_approval_request', approval);
      
      res.json(approval);
    } catch (error) {
      console.error('Error creating approval request:', error);
      res.status(500).json({ error: 'Failed to create approval request' });
    }
  });

  // Approve request endpoint
  app.post('/api/approvals/:id/approve', async (req, res) => {
    try {
      const { id } = req.params;
      const { approverId, comments } = req.body;
      
      const isComplete = await approvalService.approveRequest(id, approverId, comments);
      
      // Broadcast approval update
      broadcast('approval_updated', { approvalId: id, status: isComplete ? 'approved' : 'partial' });
      
      res.json({ approved: isComplete });
    } catch (error) {
      console.error('Error approving request:', error);
      res.status(500).json({ error: error instanceof Error ? error.message : 'Failed to approve request' });
    }
  });

  // Pending approvals endpoint
  app.get('/api/approvals/pending', async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const approvals = await storage.getPendingApprovals(userId);
      res.json(approvals);
    } catch (error) {
      console.error('Error fetching pending approvals:', error);
      res.status(500).json({ error: 'Failed to fetch pending approvals' });
    }
  });

  // Create target endpoint
  app.post('/api/targets', async (req, res) => {
    try {
      const targetData = req.body;
      const target = await storage.createTarget(targetData);
      
      // Log target creation
      await auditService.logSecurityEvent(
        'TARGET_CREATED',
        { targetId: target.id, additionalData: { hostname: target.hostname } }
      );
      
      // Broadcast new target
      broadcast('new_target', target);
      
      res.json(target);
    } catch (error) {
      console.error('Error creating target:', error);
      res.status(500).json({ error: 'Failed to create target' });
    }
  });

  // System status endpoint
  app.get('/api/system/status', async (req, res) => {
    try {
      const status = {
        safeMode: true,
        labNetwork: true,
        aiEngine: true,
        timestamp: new Date().toISOString()
      };
      
      res.json(status);
    } catch (error) {
      console.error('Error fetching system status:', error);
      res.status(500).json({ error: 'Failed to fetch system status' });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      services: {
        ai: true,
        audit: true,
        approval: true,
        storage: true
      }
    });
  });

  return httpServer;
}
