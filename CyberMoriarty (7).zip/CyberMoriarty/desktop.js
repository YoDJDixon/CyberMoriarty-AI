import pkg from 'electron';
const { app, BrowserWindow, Menu, dialog, shell, ipcMain } = pkg;
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isDev = process.env.NODE_ENV === 'development';

let mainWindow;
let serverProcess;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, 'electron/preload.js')
    },
    titleBarStyle: 'default',
    show: false,
    darkTheme: true,
    title: 'CyberMoriarty AI Exploitation Engine'
  });

  createMenu();

  // Start the backend server first
  startServer().then(() => {
    // Wait for server to be ready, then load the UI
    setTimeout(() => {
      mainWindow.loadURL('http://localhost:5000');
      
      mainWindow.once('ready-to-show', () => {
        mainWindow.show();
        console.log('CyberMoriarty Desktop launched successfully');
      });
    }, 2000);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
    if (serverProcess) {
      serverProcess.kill('SIGTERM');
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

function createMenu() {
  const template = [
    {
      label: 'CyberMoriarty',
      submenu: [
        {
          label: 'About CyberMoriarty',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About CyberMoriarty',
              message: 'CyberMoriarty AI Exploitation Engine v2.4.1',
              detail: 'Desktop Edition - Safe Mode Active\n\nAI-powered ethical penetration testing platform with comprehensive approval workflows, audit logging, and TensorFlow.js integration.',
              buttons: ['OK']
            });
          }
        },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Security',
      submenu: [
        {
          label: 'Safe Mode Status',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'Safe Mode Status',
              message: 'Safe Mode: ACTIVE',
              detail: 'Lab Network: Isolated\nAI Engine: Running\nApproval System: Enabled\n\nAll security controls are operational.',
              buttons: ['OK']
            });
          }
        },
        { type: 'separator' },
        {
          label: 'Export Audit Logs',
          click: () => {
            dialog.showSaveDialog(mainWindow, {
              filters: [
                { name: 'JSONL Files', extensions: ['jsonl'] },
                { name: 'All Files', extensions: ['*'] }
              ]
            }).then(result => {
              if (!result.canceled) {
                console.log('Export audit logs to:', result.filePath);
              }
            });
          }
        }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'Documentation',
          click: () => {
            shell.openExternal('https://docs.cybermoriarty.com');
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

async function startServer() {
  return new Promise((resolve, reject) => {
    console.log('Starting CyberMoriarty server...');
    
    // Start the Express server
    serverProcess = spawn('npm', ['run', 'dev'], {
      stdio: ['ignore', 'pipe', 'pipe'],
      shell: true
    });

    serverProcess.stdout.on('data', (data) => {
      const output = data.toString();
      console.log('[Server]', output);
      
      if (output.includes('serving on port')) {
        resolve();
      }
    });

    serverProcess.stderr.on('data', (data) => {
      console.error('[Server Error]', data.toString());
    });

    serverProcess.on('error', (error) => {
      console.error('Failed to start server:', error);
      reject(error);
    });

    serverProcess.on('exit', (code) => {
      console.log(`Server process exited with code ${code}`);
    });

    // Timeout after 10 seconds
    setTimeout(() => {
      resolve();
    }, 10000);
  });
}

// IPC handlers
ipcMain.handle('get-app-version', () => {
  return app.getVersion();
});

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
});

console.log('CyberMoriarty Desktop starting...');