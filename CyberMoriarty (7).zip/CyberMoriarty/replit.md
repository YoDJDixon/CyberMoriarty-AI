# CyberMoriarty AI Exploitation Desktop Engine

## Project Overview
An AI-powered educational cybersecurity platform built with Electron and TensorFlow.js for ethical penetration testing training. Features comprehensive approval workflows, audit logging, and isolated execution environments for authorized security testing.

## Project Architecture

### Frontend (Electron + React)
- Dashboard for target analysis and AI recommendations
- Approval request interface with two-key authorization
- Real-time audit log viewer
- AI-powered vulnerability assessment display

### Backend Services
- **API Backend**: AI decision engine, policy management, audit storage
- **Exploit Runner**: Isolated execution environment (lab mode only)
- **Policy DB**: Authorization, scope, and approval workflow management
- **CVE Resolver**: Metadata queries from NVD/KEV/Exploit-DB
- **Audit System**: Immutable logging for all actions

### AI Components (TensorFlow.js)
- Vulnerability pattern recognition
- Threat assessment scoring
- Risk analysis and recommendations
- Automated security analysis

## Tech Stack
- Frontend: Electron, React, TypeScript, Tailwind CSS, shadcn/ui
- AI: TensorFlow.js, ML5.js for neural networks
- Backend: Express.js, Node.js
- Database: In-memory storage with audit logging
- Security: Network isolation, approval workflows

## User Preferences
- Focus on ethical, educational cybersecurity training
- Comprehensive approval and audit systems required
- AI-driven recommendations with human oversight
- Professional security research environment

## Recent Changes
- ✅ **Desktop Application Implementation** (Aug 21, 2025)
  - Created comprehensive Electron main process with security menus
  - Implemented desktop mode launch functionality with floating action buttons
  - Added AI Assessment modal with TensorFlow.js integration
  - Built complete cybersecurity dashboard with dark theme
  
- ✅ **Multi-Service Architecture** (Aug 21, 2025)
  - PostgreSQL database integration with audit logging
  - AI-powered vulnerability assessment system
  - WebSocket real-time communication
  - Two-key approval workflow implementation

- ✅ **Security Framework** (Aug 21, 2025)  
  - Lab mode safety controls
  - Comprehensive audit logging system
  - Authorization and approval workflows
  - Isolated execution environment design

## Development Status
- ✅ Core application structure completed
- ✅ AI analysis capabilities with TensorFlow.js implemented
- ✅ Desktop application with Electron framework ready
- ✅ Database schema and storage layer complete
- 🔄 Final system integration and testing in progress