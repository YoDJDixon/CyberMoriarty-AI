export interface SecurityMetrics {
  activeTargets: number;
  aiRecommendations: number;
  pendingApprovals: number;
  successRate: number;
}

export interface SystemStatus {
  safeMode: boolean;
  labNetwork: boolean;
  aiEngine: boolean;
}

export interface AIRecommendation {
  id: string;
  type: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  confidence: number;
  priority: 'high' | 'medium' | 'low';
  action?: string;
}

export interface MLModelMetrics {
  accuracy: number;
  predictions: number;
  falsePositives: number;
  version: string;
  lastUpdated: string;
}

export interface TargetInfo {
  id: string;
  hostname: string;
  ipAddress: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  vulnerabilityCount: number;
  lastScan: string;
}

export interface AuditEntry {
  id: string;
  action: string;
  user: string;
  timestamp: string;
  details?: any;
  type: 'success' | 'warning' | 'error' | 'info';
}

export interface VulnerabilityAssessment {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  exploitRecommendations: string[];
  mitigationSteps: string[];
}
