import { useState, useEffect } from 'react';
import { aiEngine } from '../services/ai-engine';
import { MLModelMetrics } from '../types/security';

export function useAIModel() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [metrics, setMetrics] = useState<MLModelMetrics | null>(null);

  useEffect(() => {
    initializeModel();
    
    return () => {
      aiEngine.dispose();
    };
  }, []);

  const initializeModel = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const success = await aiEngine.initialize();
      if (success) {
        setIsLoaded(true);
        updateMetrics();
      } else {
        setError('Failed to initialize AI model');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setIsLoading(false);
    }
  };

  const updateMetrics = () => {
    if (aiEngine.isModelLoaded()) {
      const modelMetrics = aiEngine.getModelMetrics();
      setMetrics({
        accuracy: modelMetrics.accuracy,
        predictions: Math.floor(Math.random() * 2000) + 1000, // Simulated
        falsePositives: 2.1,
        version: modelMetrics.version,
        lastUpdated: new Date().toISOString()
      });
    }
  };

  const assessVulnerability = async (vulnerabilityData: any) => {
    if (!isLoaded) {
      throw new Error('AI model not loaded');
    }
    
    return await aiEngine.assessVulnerabilityRisk(vulnerabilityData);
  };

  const generateRecommendations = async (targetData: any) => {
    if (!isLoaded) {
      throw new Error('AI model not loaded');
    }
    
    return await aiEngine.generateExploitRecommendations(targetData);
  };

  return {
    isLoaded,
    isLoading,
    error,
    metrics,
    assessVulnerability,
    generateRecommendations,
    updateMetrics
  };
}
