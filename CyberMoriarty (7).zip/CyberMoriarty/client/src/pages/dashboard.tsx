import { useState, useEffect } from 'react';
import { Bell, Plus, Monitor, Brain } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sidebar } from '../components/dashboard/sidebar';
import { MetricsGrid } from '../components/dashboard/metrics-grid';
import { TargetAnalysis } from '../components/dashboard/target-analysis';
import { AIRecommendations } from '../components/dashboard/ai-recommendations';
import { ModelMetrics } from '../components/dashboard/model-metrics';
import { AuditLog } from '../components/dashboard/audit-log';
import { useAIModel } from '../hooks/use-ai-model';
import { webSocketService } from '../services/websocket';
import { useQuery } from '@tanstack/react-query';
import { 
  SecurityMetrics, 
  SystemStatus, 
  TargetInfo, 
  AIRecommendation, 
  AuditEntry 
} from '../types/security';

export default function Dashboard() {
  const [systemStatus] = useState<SystemStatus>({
    safeMode: true,
    labNetwork: true,
    aiEngine: true
  });
  
  const [isAIAssessmentOpen, setIsAIAssessmentOpen] = useState(false);

  const { isLoaded: modelLoaded, isLoading: modelLoading, metrics: modelMetrics } = useAIModel();

  // Fetch dashboard data
  const { data: metrics, isLoading: metricsLoading } = useQuery<SecurityMetrics>({
    queryKey: ['/api/dashboard/metrics'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: targets, isLoading: targetsLoading } = useQuery<TargetInfo[]>({
    queryKey: ['/api/targets'],
    refetchInterval: 60000, // Refresh every minute
  });

  const { data: recommendations, isLoading: recommendationsLoading } = useQuery<AIRecommendation[]>({
    queryKey: ['/api/ai/recommendations'],
    refetchInterval: 30000,
  });

  const { data: auditEntries, isLoading: auditLoading } = useQuery<AuditEntry[]>({
    queryKey: ['/api/audit/recent'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  useEffect(() => {
    // Initialize WebSocket connection for real-time updates
    webSocketService.connect();

    webSocketService.on('metrics_updated', (data: SecurityMetrics) => {
      // Handle real-time metrics updates
      console.log('Metrics updated:', data);
    });

    webSocketService.on('new_audit_entry', (data: AuditEntry) => {
      // Handle new audit entries
      console.log('New audit entry:', data);
    });

    webSocketService.on('new_recommendation', (data: AIRecommendation) => {
      // Handle new AI recommendations
      console.log('New recommendation:', data);
    });

    return () => {
      webSocketService.disconnect();
    };
  }, []);

  const defaultMetrics: SecurityMetrics = {
    activeTargets: 0,
    aiRecommendations: 0,
    pendingApprovals: 0,
    successRate: 0
  };

  const defaultTargets: TargetInfo[] = [];
  const defaultRecommendations: AIRecommendation[] = [];
  const defaultAuditEntries: AuditEntry[] = [];

  if (metricsLoading || targetsLoading || recommendationsLoading || auditLoading) {
    return (
      <div className="flex h-screen bg-dark-950 text-white">
        <Sidebar systemStatus={systemStatus} />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-gray-400">Loading dashboard...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-dark-950 text-white overflow-hidden">
      <Sidebar systemStatus={systemStatus} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-dark-900 border-b border-dark-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">CyberMoriarty AI Exploitation Engine</h1>
              <div className="flex items-center gap-4">
                <p className="text-sm text-gray-400">Desktop Edition v2.4.1 - Safe Mode Active</p>
                {window.location.hostname === 'localhost' && (
                  <Badge variant="outline" className="text-xs border-green-500 text-green-400">
                    DESKTOP READY
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="h-5 w-5 text-gray-400" />
                <Badge className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center p-0">
                  3
                </Badge>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <div className="text-sm font-medium text-white">Dr. Sarah Chen</div>
                  <div className="text-xs text-gray-400">Security Lead</div>
                </div>
                <div className="w-8 h-8 bg-cyber-600 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-white">SC</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <MetricsGrid metrics={metrics || defaultMetrics} />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <TargetAnalysis targets={targets || defaultTargets} />
            <AIRecommendations recommendations={recommendations || defaultRecommendations} />
          </div>

          <div className="mt-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ModelMetrics metrics={modelMetrics} isLoading={modelLoading} />
              <AuditLog entries={auditEntries || defaultAuditEntries} />
            </div>
          </div>
        </main>
      </div>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col space-y-3">
        <Button
          size="lg"
          className="w-14 h-14 rounded-full bg-purple-600 hover:bg-purple-700 shadow-lg"
          onClick={() => {
            if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
              window.open(window.location.href, '_blank', 'width=1400,height=900,scrollbars=yes,resizable=yes,menubar=no,toolbar=no,location=no,status=no');
            }
          }}
          title="Open in Desktop Mode"
        >
          <Monitor className="h-6 w-6" />
        </Button>
        <Button
          size="lg"
          className="w-14 h-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg"
          onClick={() => setIsAIAssessmentOpen(true)}
          title="AI Assessment"
        >
          <Brain className="h-6 w-6" />
        </Button>
        <Button
          size="lg"
          className="w-14 h-14 rounded-full bg-cyber-600 hover:bg-cyber-700 shadow-lg"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>

      {/* AI Assessment Modal */}
      <Dialog open={isAIAssessmentOpen} onOpenChange={setIsAIAssessmentOpen}>
        <DialogContent className="max-w-4xl bg-dark-900 border-dark-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Brain className="h-5 w-5" />
              AI Vulnerability Assessment
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-dark-800 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-white mb-2">Assessment Status</h3>
                <div className="text-green-400">✓ TensorFlow.js Model Loaded</div>
                <div className="text-green-400">✓ Neural Networks Active</div>
                <div className="text-yellow-400">⚠ Awaiting Target Selection</div>
              </div>
              <div className="bg-dark-800 p-4 rounded-lg">
                <h3 className="text-sm font-semibold text-white mb-2">Model Performance</h3>
                <div className="text-sm text-gray-300">
                  Accuracy: {modelMetrics?.accuracy || 'N/A'}
                </div>
                <div className="text-sm text-gray-300">
                  Processing Time: {modelMetrics?.processingTime || 'N/A'}ms
                </div>
                <div className="text-sm text-gray-300">
                  Confidence: {modelMetrics?.confidence || 'N/A'}
                </div>
              </div>
            </div>
            <div className="bg-dark-800 p-4 rounded-lg">
              <h3 className="text-sm font-semibold text-white mb-2">AI Recommendations</h3>
              <div className="text-sm text-gray-300">
                The AI system is ready to analyze vulnerabilities and provide security recommendations.
                Select a target from the Target Analysis section to begin assessment.
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
