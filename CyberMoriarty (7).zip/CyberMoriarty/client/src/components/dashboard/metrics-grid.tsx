import { Card, CardContent } from "@/components/ui/card";
import { Target, Brain, Clock, TrendingUp, ArrowUp, ArrowDown } from "lucide-react";
import { SecurityMetrics } from "../../types/security";

interface MetricsGridProps {
  metrics: SecurityMetrics;
}

export function MetricsGrid({ metrics }: MetricsGridProps) {
  const metricCards = [
    {
      title: "Active Targets",
      value: metrics.activeTargets.toString(),
      icon: Target,
      change: "+8%",
      changeType: "positive" as const,
      subtitle: "vs last week",
      iconColor: "text-cyber-400"
    },
    {
      title: "AI Recommendations", 
      value: metrics.aiRecommendations.toString(),
      icon: Brain,
      change: "+12%",
      changeType: "positive" as const,
      subtitle: "accuracy improved",
      iconColor: "text-purple-400"
    },
    {
      title: "Pending Approvals",
      value: metrics.pendingApprovals.toString(),
      icon: Clock,
      change: "Awaiting",
      changeType: "warning" as const,
      subtitle: "supervisor approval",
      iconColor: "text-yellow-400"
    },
    {
      title: "Success Rate",
      value: `${metrics.successRate}%`,
      icon: TrendingUp,
      change: "+2.1%",
      changeType: "positive" as const,
      subtitle: "improvement",
      iconColor: "text-green-400"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metricCards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className="bg-dark-800 border-dark-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-gray-400">{card.title}</h3>
                <Icon className={`h-5 w-5 ${card.iconColor}`} />
              </div>
              <div className="text-3xl font-bold text-white mb-2">{card.value}</div>
              <div className="flex items-center text-sm">
                {card.changeType === "positive" && (
                  <ArrowUp className="h-3 w-3 text-green-400 mr-1" />
                )}
                {card.changeType === "warning" && (
                  <ArrowDown className="h-3 w-3 text-yellow-400 mr-1" />
                )}
                <span className={
                  card.changeType === "positive" ? "text-green-400" :
                  card.changeType === "warning" ? "text-yellow-400" :
                  "text-yellow-400"
                }>
                  {card.change}
                </span>
                <span className="text-gray-400 ml-1">{card.subtitle}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
