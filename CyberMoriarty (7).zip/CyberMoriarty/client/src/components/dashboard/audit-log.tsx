import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Brain, AlertTriangle, Info } from "lucide-react";
import { AuditEntry } from "../../types/security";

interface AuditLogProps {
  entries: AuditEntry[];
}

const typeConfig = {
  'success': {
    bg: 'bg-green-600',
    icon: Check
  },
  'info': {
    bg: 'bg-cyber-600',
    icon: Brain
  },
  'warning': {
    bg: 'bg-yellow-600',
    icon: AlertTriangle
  },
  'error': {
    bg: 'bg-red-600',
    icon: AlertTriangle
  }
};

export function AuditLog({ entries }: AuditLogProps) {
  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));
    
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  };

  return (
    <Card className="bg-dark-800 border-dark-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">
            Recent Audit Log
          </CardTitle>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-cyber-400 hover:text-cyber-300"
          >
            View Full Log
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {entries.map((entry) => {
            const config = typeConfig[entry.type];
            const Icon = config.icon;
            
            return (
              <div
                key={entry.id}
                className="flex items-start space-x-3 p-3 bg-dark-700 rounded-lg"
              >
                <div className={`w-6 h-6 ${config.bg} rounded-full flex items-center justify-center flex-shrink-0 mt-0.5`}>
                  <Icon className="h-3 w-3 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-white">{entry.action}</p>
                  <div className="flex items-center space-x-4 mt-1">
                    <span className="text-xs text-gray-400">{entry.user}</span>
                    <span className="text-xs text-gray-400">
                      {formatTimeAgo(entry.timestamp)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
