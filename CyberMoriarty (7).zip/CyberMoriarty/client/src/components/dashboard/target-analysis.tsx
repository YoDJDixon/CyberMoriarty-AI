import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Server, Database, Shield, ChevronRight } from "lucide-react";
import { TargetInfo } from "../../types/security";

interface TargetAnalysisProps {
  targets: TargetInfo[];
}

const iconMap = {
  'web': Server,
  'database': Database,
  'firewall': Shield,
  'default': Server
};

const priorityColors = {
  'critical': 'bg-red-900 text-red-300',
  'high': 'bg-red-900 text-red-300',
  'medium': 'bg-yellow-900 text-yellow-300',
  'low': 'bg-green-900 text-green-300'
};

const iconColors = {
  'web': 'text-cyber-400',
  'database': 'text-green-400',
  'firewall': 'text-red-400',
  'default': 'text-cyber-400'
};

export function TargetAnalysis({ targets }: TargetAnalysisProps) {
  const getTargetType = (hostname: string): keyof typeof iconMap => {
    if (hostname.includes('web') || hostname.includes('www')) return 'web';
    if (hostname.includes('db') || hostname.includes('database')) return 'database';
    if (hostname.includes('firewall') || hostname.includes('fw')) return 'firewall';
    return 'default';
  };

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));
    
    if (hours > 0) return `${hours}h ago`;
    return `${minutes}m ago`;
  };

  return (
    <Card className="lg:col-span-2 bg-dark-800 border-dark-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">
            Recent Target Analysis
          </CardTitle>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-cyber-400 hover:text-cyber-300"
          >
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {targets.map((target) => {
            const targetType = getTargetType(target.hostname);
            const Icon = iconMap[targetType];
            
            return (
              <div
                key={target.id}
                className="flex items-center justify-between p-4 bg-dark-700 rounded-lg border border-dark-600 hover:border-dark-500 transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-cyber-800 rounded-lg flex items-center justify-center">
                    <Icon className={`h-5 w-5 ${iconColors[targetType]}`} />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">{target.hostname}</h4>
                    <p className="text-sm text-gray-400">{target.ipAddress}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <Badge className={`px-3 py-1 text-xs font-medium ${priorityColors[target.priority]}`}>
                    {target.priority === 'critical' ? 'Critical' :
                     target.priority === 'high' ? 'High Priority' :
                     target.priority === 'medium' ? 'Medium Priority' : 
                     'Low Priority'}
                  </Badge>
                  
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">
                      {target.vulnerabilityCount} vulns
                    </p>
                    <p className="text-xs text-gray-400">
                      {formatTimeAgo(target.lastScan)}
                    </p>
                  </div>
                  
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
