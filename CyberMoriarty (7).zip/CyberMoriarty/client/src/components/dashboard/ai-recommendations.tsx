import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Clock, Brain } from "lucide-react";
import { AIRecommendation } from "../../types/security";

interface AIRecommendationsProps {
  recommendations: AIRecommendation[];
}

const typeConfig = {
  'critical': {
    bg: 'bg-red-900/20 border-red-700',
    iconBg: 'bg-red-600',
    textColor: 'text-red-200',
    buttonColor: 'text-red-400 hover:text-red-300',
    icon: AlertTriangle
  },
  'warning': {
    bg: 'bg-yellow-900/20 border-yellow-700',
    iconBg: 'bg-yellow-600',
    textColor: 'text-yellow-200',
    buttonColor: 'text-yellow-400 hover:text-yellow-300',
    icon: Clock
  },
  'info': {
    bg: 'bg-cyber-900/20 border-cyber-700',
    iconBg: 'bg-cyber-600',
    textColor: 'text-cyber-200',
    buttonColor: 'text-cyber-400 hover:text-cyber-300',
    icon: Brain
  }
};

export function AIRecommendations({ recommendations }: AIRecommendationsProps) {
  return (
    <Card className="bg-dark-800 border-dark-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">
            AI Recommendations
          </CardTitle>
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations.map((recommendation) => {
            const config = typeConfig[recommendation.type];
            const Icon = config.icon;
            
            return (
              <div
                key={recommendation.id}
                className={`p-4 rounded-lg border ${config.bg}`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 ${config.iconBg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-white mb-2">
                      {recommendation.title}
                    </h4>
                    <p className={`text-sm mb-3 ${config.textColor}`}>
                      {recommendation.description}
                    </p>
                    {recommendation.action && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`p-0 h-auto font-medium ${config.buttonColor}`}
                      >
                        {recommendation.action} →
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
