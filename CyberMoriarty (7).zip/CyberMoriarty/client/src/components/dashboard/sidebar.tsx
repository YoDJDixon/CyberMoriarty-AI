import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  Gauge, 
  Target, 
  Search, 
  Brain, 
  CheckCircle, 
  FileText, 
  ShieldCheck, 
  Settings,
  Wifi,
  WifiOff,
  Activity
} from "lucide-react";
import { SystemStatus } from "../../types/security";

interface SidebarProps {
  className?: string;
  systemStatus: SystemStatus;
}

const navigationItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Gauge, active: true },
  { id: 'target-analysis', label: 'Target Analysis', icon: Target, active: false },
  { id: 'reconnaissance', label: 'AI Reconnaissance', icon: Search, active: false },
  { id: 'exploit-planning', label: 'Exploit Planning', icon: Brain, active: false },
  { id: 'approvals', label: 'Approvals', icon: CheckCircle, active: false, badge: 2 },
  { id: 'audit-logs', label: 'Audit Logs', icon: FileText, active: false },
  { id: 'ml-models', label: 'ML Models', icon: ShieldCheck, active: false },
  { id: 'compliance', label: 'Compliance', icon: Settings, active: false },
];

export function Sidebar({ className, systemStatus }: SidebarProps) {
  return (
    <div className={cn("w-64 bg-dark-900 border-r border-dark-700 flex flex-col", className)}>
      {/* Brand Header */}
      <div className="p-6 border-b border-dark-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-cyber-600 rounded-lg flex items-center justify-center">
            <Shield className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">CyberMoriarty</h1>
            <p className="text-xs text-gray-400">Desktop Edition • Safe Mode</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              className={cn(
                "w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors text-left",
                item.active 
                  ? "bg-cyber-800 text-cyber-100" 
                  : "text-gray-300 hover:bg-dark-800"
              )}
            >
              <Icon className={cn(
                "h-4 w-4",
                item.active ? "text-cyber-400" : "text-gray-400"
              )} />
              <span className="font-medium">{item.label}</span>
              {item.badge && (
                <Badge 
                  variant="secondary" 
                  className="ml-auto bg-yellow-500 text-yellow-900 text-xs px-2 py-1"
                >
                  {item.badge}
                </Badge>
              )}
            </button>
          );
        })}
      </nav>

      {/* System Status */}
      <div className="p-4 border-t border-dark-700 space-y-3">
        <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
          System Status
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300">Safe Mode</span>
            <div className="flex items-center space-x-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                systemStatus.safeMode ? "bg-green-500" : "bg-red-500"
              )} />
              <span className={cn(
                "text-xs",
                systemStatus.safeMode ? "text-green-400" : "text-red-400"
              )}>
                {systemStatus.safeMode ? "Enabled" : "Disabled"}
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300">Lab Network</span>
            <div className="flex items-center space-x-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                systemStatus.labNetwork ? "bg-blue-500" : "bg-red-500"
              )} />
              <span className={cn(
                "text-xs",
                systemStatus.labNetwork ? "text-blue-400" : "text-red-400"
              )}>
                {systemStatus.labNetwork ? "Isolated" : "Connected"}
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300">AI Engine</span>
            <div className="flex items-center space-x-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                systemStatus.aiEngine ? "bg-green-500 animate-pulse" : "bg-gray-500"
              )} />
              <span className={cn(
                "text-xs",
                systemStatus.aiEngine ? "text-green-400" : "text-gray-400"
              )}>
                {systemStatus.aiEngine ? "Active" : "Inactive"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
