import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MLModelMetrics } from "../../types/security";

interface ModelMetricsProps {
  metrics: MLModelMetrics | null;
  isLoading: boolean;
}

export function ModelMetrics({ metrics, isLoading }: ModelMetricsProps) {
  if (isLoading) {
    return (
      <Card className="bg-dark-800 border-dark-700">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-white">
            AI Model Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32">
            <div className="text-gray-400">Loading model metrics...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!metrics) {
    return (
      <Card className="bg-dark-800 border-dark-700">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-white">
            AI Model Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32">
            <div className="text-red-400">Failed to load model metrics</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return '1 day ago';
    return `${days} days ago`;
  };

  return (
    <Card className="bg-dark-800 border-dark-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">
            AI Model Performance
          </CardTitle>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-green-400">TensorFlow.js Active</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-dark-700 rounded-lg">
            <div className="text-sm text-gray-400 mb-1">Accuracy</div>
            <div className="text-2xl font-bold text-white">
              {metrics.accuracy.toFixed(1)}%
            </div>
            <div className="text-xs text-green-400">+1.2% this week</div>
          </div>
          
          <div className="p-4 bg-dark-700 rounded-lg">
            <div className="text-sm text-gray-400 mb-1">Predictions</div>
            <div className="text-2xl font-bold text-white">
              {metrics.predictions.toLocaleString()}
            </div>
            <div className="text-xs text-cyan-400">Last 24h</div>
          </div>
          
          <div className="p-4 bg-dark-700 rounded-lg">
            <div className="text-sm text-gray-400 mb-1">False Positives</div>
            <div className="text-2xl font-bold text-white">
              {metrics.falsePositives.toFixed(1)}%
            </div>
            <div className="text-xs text-red-400">-0.3% this week</div>
          </div>
          
          <div className="p-4 bg-dark-700 rounded-lg">
            <div className="text-sm text-gray-400 mb-1">Model Version</div>
            <div className="text-2xl font-bold text-white">{metrics.version}</div>
            <div className="text-xs text-gray-400">
              Updated {formatDate(metrics.lastUpdated)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
